package _01_join;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginPro.nhn")
public class LoginAction extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("get메서드 호출");
		reqPro(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("post메서드 호출");
		reqPro(request, response);
	}
	
	protected void reqPro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("reqPro메서드 호출");
		
		// jsp페이지에서 넘어온 데이터 받기
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		String dbId = "qwer";
		String dbPw = "1234";
		
		int check = -1;
		if(id.equals(dbId) && pw.equals(dbPw)) {
			check = 1;
			
			// 세션 저장
			HttpSession session = request.getSession();
			session.setAttribute("log", id);
		}
		
		// 서블릿페이지에서 jsp로 넘길 변수 저장하기
		request.setAttribute("check", check);
		
		// 서블릿페이지에서 jsp페이지로 이동하기
		RequestDispatcher dis = request.getRequestDispatcher("/00_login/loginPro.jsp");
		dis.forward(request, response);
		
	}
}







